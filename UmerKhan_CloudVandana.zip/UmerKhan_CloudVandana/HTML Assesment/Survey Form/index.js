document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("surveyForm");
  const submitButton = document.getElementById("submitButton");

  submitButton.addEventListener("click", (e) => {
    e.preventDefault();
    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const dob = document.getElementById("dob").value.trim();
    const country = document.getElementById("country").value.trim();
    const gender = document.querySelector('input[name="gender"]:checked');
    const profession = document.getElementById("profession").value.trim();
    const email = document.getElementById("email").value.trim();
    const mobile = document.getElementById("mobile").value.trim();

    if (
      !firstName ||
      !lastName ||
      !dob ||
      !country ||
      !gender ||
      !profession ||
      !email ||
      !mobile
    ) {
      alert("Please fill out all fields.");
      return;
    }

    const popupContent = `
        First Name: ${firstName}
        Last Name: ${lastName}
        Date of Birth: ${dob}
        Country: ${country}
        Gender: ${gender.value}
        Profession: ${profession}
        Email: ${email}
        Mobile Number: ${mobile}
      `;

    const userConfirmed = confirm(
      `Survey Details:\n\n${popupContent}\n\nClick OK to confirm.`
    );
    if (userConfirmed) {
      form.reset();
    }
  });
});
