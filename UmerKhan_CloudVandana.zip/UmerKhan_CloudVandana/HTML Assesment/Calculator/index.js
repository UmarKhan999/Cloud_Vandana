const display = document.getElementById("calc-display");
let currentInput = "";
let operator = "";
let previousValue = "";

const buttons = document.querySelectorAll(".btn");
buttons.forEach((button) => {
  button.addEventListener("click", (e) => {
    const value = e.target.innerText;

    if (value === "AC") {
      currentInput = "";
      operator = "";
      previousValue = "";
      display.value = "0";
    } else if (value === "=") {
      if (previousValue && operator && currentInput) {
        currentInput = calculate(previousValue, operator, currentInput);
        display.value = currentInput;
        previousValue = "";
        operator = "";
      }
    } else if (["+", "-", "*", "/"].includes(value)) {
      if (previousValue === "") {
        previousValue = currentInput;
        operator = value;
        currentInput = "";
      } else {
        currentInput = calculate(previousValue, operator, currentInput);
        display.value = currentInput;
        previousValue = currentInput;
        operator = value;
        currentInput = "";
      }
    } else {
      currentInput += value;
      display.value = currentInput;
    }
  });
});

function calculate(a, operator, b) {
  a = parseFloat(a);
  b = parseFloat(b);

  switch (operator) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b !== 0 ? a / b : "Error";
    default:
      return b;
  }
}
