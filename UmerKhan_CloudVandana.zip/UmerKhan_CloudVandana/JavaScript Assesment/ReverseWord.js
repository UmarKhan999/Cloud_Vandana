function reverseWords(sentence) {
  let result = "";
  let word = "";

  for (let i = 0; i < sentence.length; i++) {
    if (sentence[i] !== " ") {
      word = sentence[i] + word;
    } else {
      result += word + " ";
      word = "";
    }
  }

  result += word;
  return result;
}

// Example usage
const input = "This is a sunny day";
const output = reverseWords(input);
console.log(output);
