import java.util.*;

public class ShuffledArrayProgram {	
	public static void main(String[] args) {
	int[] arraytobeshuffled = {1, 2, 3, 4, 5, 6, 7};
        Random randomint = new Random();
        for (int i = arraytobeshuffled.length - 1; i > 0; i--) {
            int randominttoswap = randomint.nextInt(i + 1);
            int temp = arraytobeshuffled[i];
            arraytobeshuffled[i] = arraytobeshuffled[randominttoswap];
            arraytobeshuffled[randominttoswap] = temp;
        }      
        for(int i = 0;i<arraytobeshuffled.length;i++) {
        	System.out.print(arraytobeshuffled[i]);
        }

	}


}

