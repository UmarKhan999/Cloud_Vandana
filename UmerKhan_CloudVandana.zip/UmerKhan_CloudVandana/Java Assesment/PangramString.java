public class PangramString {    

    public static void main(String[] args) {
        char[] alphabet = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
                                     'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        String Sentence = "QWERTYUIOPASDFGHJKLZXCVBNM";
        
    
        char[] sentenceChars = new char[Sentence.length()];
        for (int i = 0; i < Sentence.length(); i++) {
            char c = Sentence.charAt(i);
            if (c >= 'a' && c <= 'z') { 
                sentenceChars[i] = (char) (c - 'a' + 'A');
            } else {
                sentenceChars[i] = c;
            }
        }
        boolean[] found = new boolean[26];
        for (int i = 0; i < found.length; i++) {
            found[i] = false; 
        }
        for (int i = 0; i < sentenceChars.length; i++) {
            for (int j = 0; j < alphabet.length; j++) {
                if (sentenceChars[i] == alphabet[j]) {
                    found[j] = true;
                    break; 
                }
            }
        }
        boolean isPangram = true;
        for (int i = 0; i < found.length; i++) {
            if (!found[i]) {
                isPangram = false;
                break; 
            }
        }
        if (isPangram) {
            System.out.println("The sentence is a pangram.");
        } else {
            System.out.println("The sentence is not a pangram.");
        }
    }
}
