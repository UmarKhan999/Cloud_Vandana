public class RomanNumber {    
    static void RomantoNumber(String Romannumber) {
        int ConvertedNumber = 0;
        int prevvalue = 0;

        for (int i = Romannumber.length() - 1; i >= 0; i--) {
            char currentChar = Romannumber.charAt(i);
            int currentValue = 0;
            
            if (currentChar == 'I') {
                currentValue = 1;
            } else if (currentChar == 'V') {
                currentValue = 5;
            } else if (currentChar == 'X') {
                currentValue = 10;
            } else if (currentChar == 'L') {
                currentValue = 50;
            } else if (currentChar == 'C') {
                currentValue = 100;
            } else if (currentChar == 'D') {
                currentValue = 500;
            } else if (currentChar == 'M') {
                currentValue = 1000;
            } else {
                System.out.println("Invalid Roman numeral: " + currentChar);
                return;
            }
            
            if (currentValue < prevvalue) {
                ConvertedNumber -= currentValue;
            } else {
                ConvertedNumber += currentValue;
            }

            prevvalue = currentValue;
        }

        System.out.println("This is the Roman Number to Number: " + ConvertedNumber);
    }

    public static void main(String[] args) {
        RomanNumber Romanobj = new RomanNumber();
        Romanobj.RomantoNumber("XXCCIII");

    }
}
